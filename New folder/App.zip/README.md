# SchoolManagement
A school management system for all the operations carried out in a school
1. open App ...
2. create html files in the templates folder while css and js in the static folder
